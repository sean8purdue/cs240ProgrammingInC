/* code that adds two numbers stored in x and y */
// 	and stores the result in z
//   	or, simply: z = x + y

int main()
{
int x, y, z;

  x = 7;
  y = 4;
  z = x + y;

}
