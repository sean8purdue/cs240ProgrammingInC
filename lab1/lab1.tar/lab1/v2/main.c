// version 2 of z = x + y
// that outputs z on the terminal
// using library function printf()

#include <stdio.h>

int main()
{
int x, y, z;

// initialize
  x = 7;
  y = 4;

// compute
  z = x + y;

// output result
  printf("results of %d + %d is %d\n", x, y, z);

}
