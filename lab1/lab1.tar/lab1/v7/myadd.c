/*	function myadd(a,b) takes two
	float arguments a and b, adds them
	and returns the result to the calling
	function */

float myadd(float a, float b)
{
float c;

// add
  c = a + b;

  return c;
}
