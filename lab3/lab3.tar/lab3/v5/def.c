#include <stdio.h>


void def(int a, int b) {

  return;

}
