void abc(void);
void def(int, int);
